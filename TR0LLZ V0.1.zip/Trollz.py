from ast import Pass
import random
from turtle import left, right
import webbrowser
import time
import tkinter as tk
from tkinter import ttk
from tkinter.messagebox import showinfo
from tkinter import *
import os
import keyboard
from itertools import cycle
from time import sleep

print('''Your PC has been FUCKED by the TR0LLZ Trojan :D

Dont Try to Close This Window or your PC will Restart :D

I have Also Created a massive folder in this folder with 100 .TXT Files :D

I have also deleted some files hope ur happy :D

''')
sleep(1)
print("----------------------------------------------")
Question = input("""TROLLZ (For Da MEMZ!)
Payloads:

1. Open Random Websites
2. Never Ending Errors
3. Notification Spam
4. Download Random Files
5. Spam Notepad
----------------------------------------------
Special:

6. Random Meme Generator
7. Rat Notifications
8. Spam Open Rat Photos
9. Rat Virus
10. ACTIVATE ALL PAYLOADS!
11. Credits
----------------------------------------------
""")

if Question == ("1"):
    print("Payload Activated! (Open Random Websites)")
    time.sleep(.500)
    webbrowser.open_new_tab('https://www.google.com/search?client=opera-gx&q=How+2+Remove+A+Virus&sourceid=opera&ie=UTF-8&oe=UTF-8')
    time.sleep(60)
    print("Payload Activated! (Open Random Websites)")
    time.sleep(.500)
    webbrowser.open_new_tab('https://www.google.com/search?client=opera-gx&q=how+2+buy+weed&sourceid=opera&ie=UTF-8&oe=UTF-8')
    open('Trollz.py')




    




