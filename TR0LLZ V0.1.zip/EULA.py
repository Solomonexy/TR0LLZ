from ast import Pass
import random
from turtle import left, right
import webbrowser
import time
import tkinter as tk
from tkinter import ttk
from tkinter.messagebox import showinfo
from tkinter import *
import os
import keyboard
from itertools import cycle
from time import sleep

texteula= '''END USER LICENSE AGREEMENT...

I (THE CREATOR) AM NOT RESPONSIPAL FOR ANY DAMAGE OR HARM CAUSED BY USING TROLLZ VIRUS
AND WHEN CLOSING THIS WINDOW YOU AGREE THAT ALL THE DAMAGE CAUSED BY TR0LLZ IS NOT
MY RESPONSIBILITY AND REPRODUCING TR0LLZ WITH ALL THE SAME FEATURES WITH ADS, PAYWALL
AND/OR OTHER MONETIZABLE METHODS. THIS WILL RESULT IN A BLACKLIST FROM ALL MY CODE THAT 
I HAVE RELEASED EVER!

DISCLAIMER: PLEASE DO NOT USE THIS WITHOUT A VIRTUAL MACHINE OR YOUR PC WILL GET FUCKED BY
THIS VIRUS. DONT USE THIS ON SCHOOL COMPUTERS YOU ANNOYING KIDS BECUASE THIS CAN BE EASILY
TRACED BACK TO YOU AND YOU WILL BE PUNISHED!




==============Please Close this window if you accept the EULA!==============
==============If you dont agree then close the command prompt window!==============


If you would like to report a bug please contact me here:
Discord: Solomonex#6969
Support Server: https://discord.gg/KkR4aMY2mR
'''

# define master
Eula = Tk()
Eula.title('END USER LICENCING AGREEMENT (EULA) - TR0LLZ Virus')

# Vertical (y) Scroll Bar
scroll = Scrollbar(Eula)
scroll.pack(side=RIGHT, fill=Y)

# Text Widget
eula = Text(Eula, wrap=NONE, yscrollcommand=scroll.set)
eula.insert("5.0", texteula)
eula.pack()

button2= Button(Eula,text='Decline',)

# Configure the scrollbars
scroll.config(command=eula.yview)

mainloop()

Question = input("""Please Choose An Option!
1. Unlock Files
2. Lock Files
""")
if Question == ("1"):
   print('Unlocking files...')
   sleep(.500)
   print('Unlocked TR0LLZ')
   os.system("attrib -h Trollz.py")
   sleep(.500)
   print('Unlocked VIRUS')
   os.system("attrib -h VIRUS.py")
   sleep(.500)
   print('Unlocked All Files Please Wait for them to unlock!')
   sleep(2)

elif Question == ("2"):
   print('locking files...')
   sleep(.500)
   print('locking TR0LLZ')
   os.system("attrib +h Trollz.py")
   sleep(.500)
   print('Locked VIRUS')
   os.system("attrib +h VIRUS.py")
   sleep(.500)
   print('Locked All Files Please Wait for them to Lock Fully!')
   sleep(2)

