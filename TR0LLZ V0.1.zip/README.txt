This is BetaTest V0.1! 

The Current Working Features Are

Option 1: Barely Works

Info: If you would like you can Remake it Fully!