This is BetaTest V0.1! 

COMMAND STATUS:

1. Open Random Websites (Online)
2. Never Ending Errors (Offline)
3. Notification Spam (Offline)
4. Download Random Files (Offline)
5. Spam Notepad (Offline)
6. Random Meme Generator (Offline)
7. Rat Notifications (Offline)
8. Spam Open Rat Photos (Offline)
9. Rat Virus (Offline)
10. ACTIVATE ALL PAYLOADS! (Offline)
11. Credits (Offline)