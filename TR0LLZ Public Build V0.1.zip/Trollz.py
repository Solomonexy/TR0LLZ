from ast import Pass
import random
from turtle import left, right
import webbrowser
import time
import tkinter as tk
from tkinter import ttk
from tkinter.messagebox import showinfo
from tkinter import *
import os
import keyboard
from itertools import cycle
from time import sleep

print('''TR0LLZ Trojan [VERSION 0.1 (Public build)]
=======================================================
Last Updated On 15 Of July 2022 
=======================================================
TR0LLZ Corperation All Rights Reserverd (DO NOT Repost)
''')
sleep(1)
print("----------------------------------------------")
Question = input("""TROLLZ (For Da MEMZ!)
Payloads:

1. Open Random Websites
2. Never Ending Errors
3. Notification Spam
4. Download Random Files
5. Spam Notepad
----------------------------------------------
Special:

6. Random Meme Generator
7. Rat Notifications
8. Spam Open Rat Photos
9. Rat Virus
10. ACTIVATE ALL PAYLOADS!
11. Credits
----------------------------------------------
""")

if Question == ("1"):
    print("Payload Activated! (Open Random Websites)")
    time.sleep(.500)
    webbrowser.open_new_tab('bit.ly/3z4VNTz')
    time.sleep(30)
    print("Payload Activated! (Open Random Websites)")
    time.sleep(.500)
    webbrowser.open_new_tab('bit.ly/3OaxaJg')
    time.sleep(30)
    print("Payload Activated! (Open Random Websites)")
    time.sleep(.500)
    webbrowser.open_new_tab('bit.ly/3ATlbNh')
    time.sleep(30)
    print("Payload Activated! (Open Random Websites)")
    time.sleep(.500)
    webbrowser.open_new_tab('bit.ly/3yHyRZa')
    time.sleep(30)
    print("Payload Activated! (Open Random Websites)")
    time.sleep(.500)
    webbrowser.open_new_tab('bit.ly/3yHyRZa')
    time.sleep(30)
    print("Payload Activated! (Open Random Websites)")
    time.sleep(.500)
    webbrowser.open_new_tab('bit.ly/3IFhpJi')
    time.sleep(30)
    print("Payload Activated! (Open Random Websites)")
    time.sleep(.500)
    webbrowser.open_new_tab('bit.ly/3yC4L9k')
    open('Trollz.py')




    




